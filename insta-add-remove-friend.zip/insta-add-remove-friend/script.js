let stus = document.querySelector("h5");
let addF = document.querySelector("#add");
let flag = 0;
addF.addEventListener("click", function () {
    if (flag == 0) {
        stus.innerHTML = "Friends";
        stus.style.color = "green";
        addF.innerHTML = "Remove Friend"
        flag = 1;
    }else{
        stus.innerHTML = "Stranger";
        stus.style.color = "red";
        flag = 0;
        addF.innerHTML = "Add Friend"
    }
})